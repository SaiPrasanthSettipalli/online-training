package com.otms.service;

import java.util.List;

import com.otms.entity.Course;

public interface ICourseService {

	String addCourse(Course course);
	// String addCourse(Course course);
  Course checkCourseDetails(String courseName);
   List<Course> getAllCourses();
   List<Course> deleteCourse(String courseName);
}

