package com.otms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.otms.dao.ICourseDao;
import com.otms.entity.Course;

@Service
public class CourseServiceImpl implements ICourseService{

	@Autowired
	ICourseDao courseDao;

	@Override
	public String addCourse(Course course) {
		//user.setPassword(user.getPassword());
		return courseDao.addCourse(course);
	}

	@Override
	public Course checkCourseDetails(String courseName) {
		Course course=courseDao.checkCourseDetails(courseName);
		if(course==null) {
			return null;
		}
//		String userPassword=user.getPassword(); 
//		if(userPassword.matches(password)) {
//			return user;	
//		}

		return course;
	}
	@Override
	public List<Course> getAllCourses(){
		return courseDao.getAllCourses();
	}
	@Override
	public List<Course> deleteCourse(String courseName) {
		return courseDao.deleteCourse(courseName);
	}
}
