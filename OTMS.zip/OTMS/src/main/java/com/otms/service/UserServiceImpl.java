package com.otms.service;

import java.util.Base64;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.otms.dao.IUserDao;
import com.otms.entity.User;

@Service
public class UserServiceImpl implements IUserService{
	@Autowired
	IUserDao userDao;

	@Override
	public String registerUser(User user) {
		//user.setPassword(user.getPassword());
		return userDao.registerUser(user);
	}

	/*
	 * public static String toEncode(String message) { return
	 * Base64.getEncoder().encodeToString(message.getBytes()); }
	 */
	@Override
	public User checkLoginDetails(String userEmail, String password) {
		User user=userDao.checkLoginDetails(userEmail,password);
		if(user==null) {
			return null;
		}
		String userPassword=user.getPassword(); 
		if(userPassword.matches(password)) {
			return user;	
		}
		 return null;
	}
	/*
	 * public static String toDecode(String message) { byte[] decodedBytes =
	 * Base64.getDecoder().decode(message); return new String(decodedBytes); }
	 */
}
