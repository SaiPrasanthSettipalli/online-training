package com.otms.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document

public class Course {
	@Id
	private String courseName;
	private String courseVideo;
	private String courseDescription;
	private String courseFeatures;
	private String questions;
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getCourseVideo() {
		return courseVideo;
	}
	public void setCourseVideo(String courseVideo) {
		this.courseVideo = courseVideo;
	}
	public String getCourseDescription() {
		return courseDescription;
	}
	public void setCourseDescription(String courseDescription) {
		this.courseDescription = courseDescription;
	}
	public String getCourseFeatures() {
		return courseFeatures;
	}
	public void setCourseFeatures(String courseFeatures) {
		this.courseFeatures = courseFeatures;
	}
	public String getQuestions() {
		return questions;
	}
	public void setQuestions(String questions) {
		this.questions = questions;
	}
	public Course(String courseName, String courseVideo, String courseDescription, String courseFeatures,
			String questions) {
		super();
		this.courseName = courseName;
		this.courseVideo = courseVideo;
		this.courseDescription = courseDescription;
		this.courseFeatures = courseFeatures;
		this.questions = questions;
	}
	public Course() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Course [courseName=" + courseName + ", courseVideo=" + courseVideo + ", courseDescription="
				+ courseDescription + ", courseFeatures=" + courseFeatures + ", questions=" + questions + "]";
	}
	
	
}
