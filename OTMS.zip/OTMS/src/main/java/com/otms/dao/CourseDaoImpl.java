package com.otms.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.otms.entity.Course;


@Repository
public class CourseDaoImpl implements ICourseDao
{

	@Autowired
	MongoTemplate mongoTemplate;
	

	@Override
	public String addCourse(Course course) {
		if(checkCourse(course.getCourseName())!=null)
		return null;
		
		mongoTemplate.save(course);
		return "saved";
	}
	public Course checkCourse(String courseName) {
		Query query=new Query();
		query.addCriteria(Criteria.where("courseName").is(courseName));
		return mongoTemplate.findOne(query,Course.class);
	}
	
	
	@Override
	public Course checkCourseDetails(String courseName) {
		Course course=checkCourse(courseName);
		//System.out.println("Jyothika"+course);
		if(course==null)
		{
			return null;
		}
		return course;
	}
	@Override
	public List<Course> getAllCourses(){
		return mongoTemplate.findAll(Course.class);
	}
	@Override
	public List<Course> deleteCourse(String courseName) {
		Query query=new Query();
		query.addCriteria(Criteria.where("courseName").is(courseName));
		Course course=mongoTemplate.findOne(query, Course.class);
		if(course!=null) {
			mongoTemplate.remove(query, Course.class);
			return mongoTemplate.findAll(Course.class);
		}
		return null;
		}
	}

