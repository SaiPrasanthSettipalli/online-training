package com.otms.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.otms.entity.User;

@Repository
public class UserDaoImpl implements IUserDao{

	@Autowired
	MongoTemplate mongoTemplate;

	@Override
	public String registerUser(User user) {
		if(checkUser(user.getUserEmail())!=null)
		return null;
		
		mongoTemplate.save(user);
		return "saved";
	}
	public User checkUser(String userEmail) {
		Query query=new Query();
		query.addCriteria(Criteria.where("userEmail").is(userEmail));
		return mongoTemplate.findOne(query,User.class);
	}
	
	@Override
	public User checkLoginDetails(String userEmail, String password) {
		User user=checkUser(userEmail);
		if(user==null)
		{
			return null;
		}
		return user;
	}

}
