package com.otms.dao;

import java.util.List;

import com.otms.entity.Course;

public interface ICourseDao {
	String addCourse(Course course);
	Course checkCourseDetails(String courseName);
List<Course> getAllCourses();

List<Course> deleteCourse(String courseName);
}
