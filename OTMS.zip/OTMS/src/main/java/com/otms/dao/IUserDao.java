package com.otms.dao;

import com.otms.entity.User;

public interface IUserDao {
	String registerUser(User user);
	User checkLoginDetails(String userEmail, String password);
}
