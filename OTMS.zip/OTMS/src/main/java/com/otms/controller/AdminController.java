package com.otms.controller;

public class AdminController {

}
