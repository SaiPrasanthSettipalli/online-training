package com.otms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.otms.entity.Course;
import com.otms.service.ICourseService;


@RestController
@RequestMapping("/course")
public class CourseController {

	@Autowired
	ICourseService courseService;
	
	@PostMapping("/addCourse")
	public Boolean addCourse(@RequestBody Course course) {
		if(courseService.addCourse(course) != null)
			{System.out.println(course);
			return true;
			}
		return false;
	}
	
	@GetMapping("/getAllCourses")
	public List<Course> getAllCourses(){
		return courseService.getAllCourses();
	}
	
	@GetMapping("/getCourse")
	public Course checkCourseDetails(@RequestParam String courseName){
		Course course=courseService.checkCourseDetails(courseName);
		if( course!= null)
		{
			return course;
		}
		return null;
	}
	@DeleteMapping("/deleteCourse")
	public List<Course> deleteCourse(@RequestParam String courseName) {
		return courseService.deleteCourse(courseName);
	}
}
