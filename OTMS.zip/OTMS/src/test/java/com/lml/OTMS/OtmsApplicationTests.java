package com.lml.OTMS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OtmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
